( function( global, factory ) {

	"use strict";

	if ( typeof module === "object" && typeof module.exports === "object" ) {
		module.exports = global.document ?
			factory( global, true ) :
			function( w ) {
				if ( !w.document ) {
					throw new Error( "rpc requires a window with a document" );
				}
				return factory( w );
			};
	} else {
		factory( global );
	}

} )( typeof window !== "undefined" ? window : this, function( window, noGlobal ) {

"use strict";

var list = [
    {
        "method": "getBlockTransactionCountByHash",
        "params": [
            {
                "name": "hash",
                "type": "string"
            }
        ]
    },
    {
        "method": "getBlockTransactionCountByNumber",
        "params": [
            {
                "name": "num",
                "type": "number"
            }
        ]
    },
    {
        "method": "getTransactionByBlockHashAndIndex",
        "params": [
            {
                "name": "hash",
                "type": "string"
            },
            {
                "name": "index",
                "type": "number"
            }
        ]
    },
    {
        "method": "sendRawTransaction",
        "params": [
            {
                "name": "blob",
                "type": "string",
                "multi": true
            }
        ]
    },
    {
        "method": "callRawTransaction",
        "params": [
            {
                "name": "blob",
                "type": "string",
                "multi": true
            }
        ]
    },
    {
        "method": "uploadData",
        "params": [
            {
                "name": "blob",
                "type": "string",
                "multi": true
            }
        ],
        "list":true
    },
    {
        "method": "downloadData",
        "params": [
            {
                "name": "hash",
                "type": "string"
            }
        ],
        "list":true
    },
    {
        "method": "uploadFile",
        "params": [
            {
                "name": "file",
                "type": "file"
            }
        ],
        "form":true
    },
    {
        "method": "downloadFile",
        "params": [
            {
                "name": "hash",
                "type": "string"
            },
            {
                "name": "name",
                "type": "string"
            }
        ],
        "download":true
    },
    {
        "method": "createWallet",
        "params": [
            {
                "name": "password",
                "type": "string"
            }
        ]
    },
    {
        "method": "createAccount",
        "params": [
            {
                "name": "name",
                "type": "string"
            }
        ]
    },
    {
        "method": "getAccount",
        "params": [
            {
                "name": "name",
                "type": "string"
            }
        ]
    },
    {
        "method": "listAccount",
        "params": []
    },
    {
        "method": "sendTransaction",
        "params": [
            {
                "name": "account",
                "type": "string"
            },
            {
                "name": "data",
                "type": "string",
                "multi": true
            }
        ]
    },
    {
        "method": "callTransaction",
        "params": [
            {
                "name": "account",
                "type": "string"
            },
            {
                "name": "data",
                "type": "string",
                "multi": true
            }
        ]
    },
    {
        "method": "signTransaction",
        "params": [
            {
                "name": "account",
                "type": "string"
            },
            {
                "name": "data",
                "type": "string",
                "multi": true
            }
        ]
    },
    {
        "method": "getBlockByNumber",
        "params": [
            {
                "name": "num",
                "type": "number"
            }
        ]
    },
    {
        "method": "blockNumber",
        "params": []
    },
    {
        "method": "getTransactionByHash",
        "params": [
            {
                "name": "hash",
                "type": "string"
            }
        ]
    },
    {
        "method": "getTransactionByBlockNumberAndIndex",
        "params": [
            {
                "name": "num",
                "type": "number"
            },
            {
                "name": "index",
                "type": "number"
            }
        ]
    },
    {
        "method": "getBlockByHash",
        "params": [
            {
                "name": "hash",
                "type": "string"
            }
        ]
    },
    {
        "method": "getTransactionReceipt",
        "params": [
            {
                "name": "hash",
                "type": "string"
            }
        ]
    }
];

var RPC = function(n, apiHost, apiPort, apiAsync) {
    var rpc = {
        id:0,
        name:n,
        apiHost:apiHost,
        apiPort:apiPort,
        apiAsync:(typeof apiAsync == "undefined" ? true : false),
        post: function(id, method, params, callback) {
            $.post(
                {
                    url: location.protocol + "//" + (this.apiHost != null ? this.apiHost : location.hostname) + ":" + (this.apiPort != 0 ? this.apiPort : location.port) + "/v1/jsonrpc",
                    contentType: "application/json; charset=utf-8",
                    data: JSON.stringify({
                        "jsonrpc":"2.0",
                        "id":id,
                        "method":method, 
                        "params":params,
                    }),
                    dataType: "json",
                    async: this.apiAsync,
                    success: function(result){
                        callback && callback(result);
                    },
                    error: function (message) {
                        callback && callback(message);
                    }
                }
            );
        },
        postForm: function(id, method, params, callback) {
            var fd = new FormData();
            var ps = [];
            for(var i = 0; i < params.length; i ++){
                var p = params[i];
                var fileId = p["file"];
                fd.append("file"+i, $(fileId)[0].files[0]);
                delete p["file"];
                ps.push(p);
            }
            fd.append("request", JSON.stringify({
                "jsonrpc":"2.0",
                "id":id,
                "method":method, 
                "params":ps,
            }));
            $.post(
                {
                    url: location.protocol + "//" + (this.apiHost != null ? this.apiHost : location.hostname) + ":" + (this.apiPort != 0 ? this.apiPort : location.port) + "/v1/jsonrpc",
                    contentType: false,
                    processData: false,
                    data: fd,
                    dataType: "json",
                    async: this.apiAsync,
                    success: function(result){
                        callback && callback(result);
                    },
                    error: function (message) {
                        callback && callback(message);
                    }
                }
            );
        },
        postDownload: function(id, method, params, callback) {
            $.post(
                {
                    url: location.protocol + "//" + (this.apiHost != null ? this.apiHost : location.hostname) + ":" + (this.apiPort != 0 ? this.apiPort : location.port) + "/v1/jsonrpc",
                    contentType: "application/json; charset=utf-8",
                    data: JSON.stringify({
                        "jsonrpc":"2.0",
                        "id":id,
                        "method":method, 
                        "params":params,
                    }),
                    processData:false,
                    async: this.apiAsync,
                    dataType: 'binary',
                    responseType: 'blob',
                    // xhr: function() {
                    //     var xhr = $.ajaxSettings.xhr();
                    //     if(xhr.upload){
                    //         xhr.upload.addEventListener("progress", function(e){
                    //             var loaded = e.loaded;
                    //             var total = e.total;
                    //             var percent = loaded / total;
                    //             console.log(percent);
                    //         }, false);
                    //     }
                    //     return xhr;
                    // },
                    success: function(blob, textStatus, response) {
                        console.log("<", textStatus, typeof blob, blob.size);

                        var header = response.getResponseHeader('Content-Disposition');
                        var fileName = (header != null ? header.split("=")[1] : params[1]);
                        var fileType = response.getResponseHeader("Content-Type");
                        var fileSize = response.getResponseHeader("Content-Length");
                        callback && callback({
                            name: fileName,
                            size: Number(fileSize),
                            type: fileType,
                            blob: blob
                        });
                    },
                    error: function (error) {
                        callback && callback(error);
                    }
                }
            );
        }
    };

    function isArray (o) {
        return Object.prototype.toString.call(o) === '[object Array]';
    }

    function validateItem(p, t) {
        if(t.type == "file"){
            if($(p).val().length == 0){
                alert("error parameter type for " + t.name);
                return false;
            }
        }else{
            if((typeof p != t.type && !(t.type == "list" && isArray(p))) || p.length == 0){
                alert("error parameter type for " + t.name);
                return false;
            }
            if(t.type == "object") {
                var otypes = t.params;
                for(var k = 0; k < otypes.length; k ++){
                    var ot = otypes[k];
                    if(!validateItem(p[ot.name], ot)){
                        return false;
                    }
                }
            }
        }
        return true;
    }

    function validate(params, types) {
        for(var i = 0; i < params.length; i ++){
            var o = params[i];
            for(var j = 0; j < types.length; j ++){
                var t = types[j];
                var p = o[t.name]
                if(!validateItem(p, t)){
                    return false;
                }
            }
        }
        return true;
    }

    var map = {};
    for(var i = 0; i < list.length; i ++) {
        var item = list[i];
        item.f = function(item) {
            return function() {
                var callback = arguments[arguments.length - 1];
                var params = [].slice.call(arguments, 0, arguments.length - 1);
                var types = item.params;
                if(!validate(params, types)){
                    return;
                }
                if(item.form){
                    this.postForm(this.id ++, item.method, params, callback);
                }else{
                    if(item.download){
                        this.postDownload(this.id ++, item.method, params, callback);
                    }else{
                        this.post(this.id ++, item.method, params, callback);
                    }
                }
            };
        }(item);
        map[item.method] = item;
    }
    rpc.list = list;
    rpc.map = map;
    rpc.BytesToHex = function(bytes) {
        for (var hex = [], i = 0; i < bytes.length; i++) {
            hex.push((bytes[i] >>> 4).toString(16));
            hex.push((bytes[i] & 0xF).toString(16));
        }
        return hex.join("");
    }
    return rpc;
};

var rpc = new RPC("rpc");
rpc.RPC = RPC;

if ( !noGlobal ) {
	window.rpc = rpc;
}

return rpc;
} );