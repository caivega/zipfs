( function( global, factory ) {

	"use strict";

	if ( typeof module === "object" && typeof module.exports === "object" ) {
		module.exports = global.document ?
			factory( global, true ) :
			function( w ) {
				if ( !w.document ) {
					throw new Error( "data requires a window with a document" );
				}
				return factory( w );
			};
	} else {
		factory( global );
	}

} )( typeof window !== "undefined" ? window : this, function( window, noGlobal ) {

"use strict";

var Client = function(apiHost, apiPort) {
    var r = new rpc.RPC("client");
    r.apiHost = apiHost;
    r.apiPort = apiPort;
    r.apiAsync = false;

    var client = {
        apiHost: apiHost,
        apiPort: apiPort,
        rpc: r,

        getHost: function() {
            return this.apiHost;
        },

        getPort: function() {
            return this.apiPort;
        },
        
        post: function(name, method, params, callback) {
            var paramString = JSON.stringify(params);
            if(paramString.length > 256) {
                console.log("> " + method + "\t" + name);
            }else{
                console.log("> " + method + "\t" + paramString + "\t" + name);
            }

            var item = this.rpc.map[method];
            if(item == null || item.params.length != params.length){
                console.log("> error " + paramString);
                return;
            }
            var list = item.params;

            var m = {};
            for(var i = 0; i < list.length; i ++){
                var p = list[i];

                var n = p.name;
                var t = p.type;
                if("object" != (t)){
                    m[n] = params[i];
                }else{
                    var sublist = p.params;
                    var subps = params[i];
                    if(sublist == null || sublist.length != subps.length){
                        console.log("> error " + paramString);
                        return;
                    }
                    var subm = {};
                    for(var j = 0; j < sublist.length; j ++){
                        var subp = sublist[j];
                        var subn = subp.name;
                        subm[subn] = subps[j];
                    }
                    m[n] = subm;
                }
            }

            params = [m];
            paramString = JSON.stringify(params);
            if(paramString.length < 256){
                console.log(">> " + method + "\t" + paramString + "\t" + name);
            }

            var response = null;
            var item = this.rpc.map[method];
            if(item != null){
                if(callback != null){
                    params.push(callback);    
                }else{
                    params.push(function(res){
                        response = res;

                        if(item.download){
                            console.log("< " + JSON.stringify({
                                name: res.name,
                                size: res.size,
                                type: res.type
                            }));
                        }else{
                            console.log("< " + JSON.stringify(res));
                        }
                    });
                }
                item.f.apply(this.rpc, params);
            }else{
                console.log("unsupport method [" + method + "]"); 
                response = {result:{}};
            }
            return response;
        },

        sendTransaction: function(name, account, transaction) {
            return this.processTransaction(name, "sendTransaction", account, transaction);
        },

        callTransaction: function(name, account, transaction) {
            return this.processTransaction(name, "callTransaction", account, transaction);
        },

        signTransaction: function(name, account, transaction) {
            return this.processTransaction(name, "signTransaction", account, transaction);
        },

        sendRawTransaction: function(name, blob) {
            return this.post(name, "sendRawTransaction", [blob]);
        },

        callRawTransaction: function(name, blob) {
            return this.post(name, "callRawTransaction", [blob]);
        },

        uploadData: function(list) { // blobs(hex strings)
            console.log("> upload " + list.length + " datas");
            return this.post("upload data", "uploadData", list);
        },

        downloadData: function(hash) {
            return this.post("download data", "downloadData", [hash]);
        },

        uploadFile: function(list) { // ids such as: #file1, #file2...
            console.log("> upload " + list.length + " files");
            return this.post("upload files", "uploadFile", list);
        },

        downloadFile: function(hash, nameOrCallback, callback) {
            if(nameOrCallback != null){
                if(typeof nameOrCallback == "string"){
                    return this.post("download file", "downloadFile", [hash, nameOrCallback], callback);
                }else{
                    return this.post("download file", "downloadFile", [hash, hash], nameOrCallback);
                }
            }else{
                return this.post("download file", "downloadFile", [hash, hash]);
            }
        }
    };
    return client;
};

if ( !noGlobal ) {
	window.Client = Client;
}

return Client;
} );