(function($, window, undefined) {
	// this is just a test
})(jQuery, window);